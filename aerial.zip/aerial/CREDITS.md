CREDITS
=======

- A huge thanks to the helpful community at [the official Minetest Discord server](https://discord.gg/minetest), especially MinetestVideos, GreenXenith, and Lemente
- Thanks to Malcolm Riley for publishing [a large collection of textures](https://github.com/malcolmriley/unused-textures) under the [CC-BY 4.0 license](https://creativecommons.org/licenses/by/4.0/), some of which were used as the basis for the wing textures in this mod

Tools
-----

- Wings 3D model created using [Blender](https://www.blender.org/)
- Wing textures created using [GIMP](https://www.gimp.org/)
